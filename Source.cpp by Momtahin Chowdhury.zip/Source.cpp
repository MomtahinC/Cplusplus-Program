#include <iostream>
#include <string>
#include <vector>
using namespace std;

int main() {
	//all the variables in double to get decimal places
	double initialAmount = 0.00; double monthlyAmount = 0.00; double annualInterest = 0.00;
	int numYears=0;
	int months = numYears * 12;
	double interestRate=0.00; 
	double yearEndBalance=0.00; 
	double closingAmount = 0.00;
	
	//Displaing the menu
	
	cout << "**********************************"<< endl;
	cout << "**********"<<" Data Input " << "************" << endl;
	cout << "Initial Investment Amount: "<<endl;
	cout << "Monthly Deposit: " << endl;
	cout << "Annual Interest: " << endl;
	cout << "Number of years: " << endl;
	system("Pause"); //this command will automatically pause the program and will only continiue if any key is press//this will 
	                //also print out the cout << "Press any key to continue . . . " << endl;
	

	//getting input for each step 
	cout << endl<<"**********************************"<< endl;
	cout << "**********"<<" Data Input " << "************" << endl;
	
	cout << "Initial Investment Amount: $";                  //get the initial amount 
	cin >> initialAmount;
	

	cout << "Monthly Deposit: $";                               //get the monthly deposit
	cin >> monthlyAmount;

	
	cout << "Annual Interest: %";                             //get the rate of interest in percentage 
	cin >> annualInterest;

	
	cout << "Number of years: ";                                //investment for the number of years
	cin >> numYears;

	system("Pause");                                         //pause the program
	//cout << "Press any key to continue . . . " << endl;
	

	cout << endl;

	
	//printing out the end to year balance 

    cout<<"  Balance and Interest Without Additional Monthly Deposits  " << endl;

	cout << "==============================================================" << endl;
	cout << "  Year       Year End Balance          Year End Earned Interest" << endl;
	cout << "--------------------------------------------------------------" << endl;
	
	
	yearEndBalance = initialAmount;
	 double yearlyAmount = 0.00;
	 double total = initialAmount + monthlyAmount;

	//going rhrough all the years to get the interst rate.
	for (int i = 1; i <= numYears; i++) {
		 yearlyAmount = ((yearEndBalance) * ((annualInterest / 100)));   
		yearEndBalance= yearEndBalance + yearlyAmount;
		cout << "  " << i << "             $";
		printf("%.2f", yearEndBalance);    //get the precision upto 2 decimal place
		cout <<"                       $"; 
		printf("%.2f", yearlyAmount);
		cout<< endl;
		cout << endl;
	}
	//printing out the year to end with each month insluded.
	cout << endl;
	cout << "  Balance and Interest With Additional Monthly Deposits  " << endl;
	cout << "==============================================================" << endl;
	cout << "  Year           Year End Balance          Year End Earned Interest" << endl;
	cout << "--------------------------------------------------------------" << endl;
	
	
	yearEndBalance = initialAmount;
	double yearToEns = 0.00;
	closingAmount = initialAmount;

	for (int j = 1; j <= numYears; j++) {                              //go through each year 
		for (int k = 0; k < 12; k++) {                                 //go through each month in each year 
			interestRate = (closingAmount + monthlyAmount) * ((annualInterest / 100) / 12);   //interest formual from the document
			yearToEns += interestRate;
			closingAmount += (interestRate + monthlyAmount);
		}
		
		cout << "  " << j << "                    $";                  //print out the year
		printf("%.2f", closingAmount);                               //print out the money with 2 decimal place precison 
		cout << "                     $";
		printf("%.2f", yearToEns);
		cout<< endl;
		cout << endl;
		yearToEns = 0.00;                                         //reset the value to zero.
	}
	
	return 0;
		
}